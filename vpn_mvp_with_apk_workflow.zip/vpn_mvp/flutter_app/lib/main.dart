import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/activation_screen.dart';
import 'screens/home_screen.dart';

void main() => runApp(const VpnMvpApp());

class VpnMvpApp extends StatelessWidget {
  const VpnMvpApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VPN MVP',
      theme: ThemeData(colorSchemeSeed: Colors.blue, useMaterial3: true),
      home: const Bootstrap(),
    );
  }
}

class Bootstrap extends StatefulWidget {
  const Bootstrap({super.key});
  @override State<Bootstrap> createState() => _BootstrapState();
}

class _BootstrapState extends State<Bootstrap> {
  String? token;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => token = prefs.getString('token'));
  }
  @override
  Widget build(BuildContext context) => token == null ? ActivationScreen(onActivated: _load) : HomeScreen(token: token!);
}
