class AuthResult {
  final int userId;
  final DateTime expireDate;
  final bool subscriptionActive;

  AuthResult({required this.userId, required this.expireDate, required this.subscriptionActive});

  factory AuthResult.fromJson(Map<String, dynamic> json) => AuthResult(
        userId: json['user_id'],
        expireDate: DateTime.parse(json['expire_date']),
        subscriptionActive: json['subscription_active'],
      );
}
