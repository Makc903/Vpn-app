class VpnConfig {
  final int serverId;
  final String country;
  final String city;
  final String protocol;
  final String endpoint;
  final String config;

  VpnConfig({required this.serverId, required this.country, required this.city, required this.protocol, required this.endpoint, required this.config});

  factory VpnConfig.fromJson(Map<String, dynamic> json) => VpnConfig(
        serverId: json['server_id'],
        country: json['country'],
        city: json['city'] ?? '',
        protocol: json['protocol'],
        endpoint: json['endpoint'],
        config: json['config'],
      );
}
