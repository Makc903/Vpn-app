import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/auth_result.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key, required this.token, required this.auth});
  final String token;
  final AuthResult? auth;

  Future<void> pay() async {
    final uri = Uri.parse('https://t.me/your_bot?start=${Uri.encodeComponent(token)}');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Аккаунт')),
    body: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text('Статус подписки: ${auth?.subscriptionActive == true ? 'активна' : 'неактивна'}'),
      const SizedBox(height: 8),
      Text('Дата окончания: ${auth?.expireDate.toLocal().toString() ?? 'нет данных'}'),
      const SizedBox(height: 24),
      FilledButton(onPressed: pay, child: const Text('Оплатить / продлить в Telegram')),
    ])),
  );
}
