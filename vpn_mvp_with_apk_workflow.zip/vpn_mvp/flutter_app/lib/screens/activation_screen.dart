import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_client.dart';

class ActivationScreen extends StatefulWidget {
  const ActivationScreen({super.key, required this.onActivated});
  final VoidCallback onActivated;
  @override State<ActivationScreen> createState() => _ActivationScreenState();
}

class _ActivationScreenState extends State<ActivationScreen> {
  final tokenController = TextEditingController();
  final api = ApiClient(baseUrl: const String.fromEnvironment('API_BASE', defaultValue: 'http://localhost:8000'));
  bool loading = false;
  String? error;

  Future<void> activate() async {
    setState(() { loading = true; error = null; });
    try {
      await api.auth(tokenController.text.trim());
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('token', tokenController.text.trim());
      widget.onActivated();
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Активация')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('Введите ключ доступа из Telegram-бота'),
        const SizedBox(height: 12),
        TextField(controller: tokenController, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'UUID / Token')),
        const SizedBox(height: 12),
        FilledButton(onPressed: loading ? null : activate, child: Text(loading ? 'Проверяем...' : 'Активировать')),
        if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
      ]),
    ),
  );
}
