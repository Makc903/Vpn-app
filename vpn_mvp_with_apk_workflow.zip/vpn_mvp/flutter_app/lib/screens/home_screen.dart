import 'package:flutter/material.dart';
import '../models/auth_result.dart';
import '../models/vpn_config.dart';
import '../services/api_client.dart';
import '../services/vpn_service.dart';
import 'account_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.token});
  final String token;
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final api = ApiClient(baseUrl: const String.fromEnvironment('API_BASE', defaultValue: 'http://localhost:8000'));
  final vpn = VpnService();
  AuthResult? auth;
  VpnConfig? config;
  String? error;

  @override void initState() { super.initState(); refresh(); }

  Future<void> refresh() async {
    try {
      final a = await api.auth(widget.token);
      final c = await api.getConfig(widget.token);
      setState(() { auth = a; config = c; error = null; });
    } catch (e) { setState(() => error = e.toString()); }
  }

  Future<void> toggle() async {
    if (vpn.state == VpnState.connected) {
      await vpn.disconnect();
    } else if (config != null) {
      await vpn.connect(config!);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('VPN MVP'), actions: [IconButton(icon: const Icon(Icons.person), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AccountScreen(token: widget.token, auth: auth))))]),
    body: Center(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text(config == null ? 'Сервер не выбран' : '${config!.country} ${config!.city} · ${config!.protocol.toUpperCase()}'),
      const SizedBox(height: 24),
      SizedBox(width: 180, height: 180, child: FilledButton.tonal(onPressed: config == null ? null : toggle, child: Text(vpn.state == VpnState.connected ? 'Выкл' : 'Вкл', style: const TextStyle(fontSize: 32)))),
      const SizedBox(height: 20),
      Text('Статус: ${vpn.state.name}'),
      if (auth != null) Text('Подписка до: ${auth!.expireDate.toLocal()}'),
      if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
      TextButton(onPressed: refresh, child: const Text('Обновить статус')),
    ]))),
  );
}
