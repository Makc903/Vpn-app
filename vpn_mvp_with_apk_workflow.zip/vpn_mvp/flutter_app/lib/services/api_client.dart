import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/auth_result.dart';
import '../models/vpn_config.dart';

class ApiClient {
  ApiClient({required this.baseUrl});
  final String baseUrl;

  Future<AuthResult> auth(String token, {String? deviceId}) async {
    final res = await http.post(Uri.parse('$baseUrl/api/client/auth'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'token': token, 'device_id': deviceId}));
    if (res.statusCode >= 400) throw Exception(_error(res));
    return AuthResult.fromJson(jsonDecode(res.body));
  }

  Future<VpnConfig> getConfig(String token) async {
    final res = await http.get(Uri.parse('$baseUrl/api/client/config?token=${Uri.encodeComponent(token)}'));
    if (res.statusCode >= 400) throw Exception(_error(res));
    return VpnConfig.fromJson(jsonDecode(res.body));
  }

  Future<void> report(String token, int serverId, int txBytes, int rxBytes) async {
    await http.post(Uri.parse('$baseUrl/api/client/report'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'token': token, 'server_id': serverId, 'tx_bytes': txBytes, 'rx_bytes': rxBytes}));
  }

  String _error(http.Response res) {
    try { return jsonDecode(res.body)['detail'].toString(); } catch (_) { return res.body; }
  }
}
