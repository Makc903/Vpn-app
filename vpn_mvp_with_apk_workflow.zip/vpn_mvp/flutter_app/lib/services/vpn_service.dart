import '../models/vpn_config.dart';

enum VpnState { disconnected, connecting, connected, failed }

class VpnService {
  VpnState state = VpnState.disconnected;

  Future<void> connect(VpnConfig config) async {
    state = VpnState.connecting;
    // TODO Android: MethodChannel -> VpnService + sing-box/xray-core.
    // TODO iOS: MethodChannel -> NetworkExtension PacketTunnelProvider.
    // На MVP-этапе сюда передается config.config, полученный с API.
    await Future.delayed(const Duration(seconds: 1));
    state = VpnState.connected;
  }

  Future<void> disconnect() async {
    state = VpnState.disconnected;
  }
}
